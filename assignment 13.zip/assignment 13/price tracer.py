import requests
from bs4 import BeautifulSoup
from werkzeug.datastructures import Headers


class PriceTracer:
    def __init__(self, url):
        self.url = url
        self.user_agent = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36" }

        self.response = requests.get(url=self.url, headers = self.user_agent).text
        self.soup = BeautifulSoup(self.response , "lxml")

    def product_title(self):
        title = self.soup.find("span" , {"id": "productTitle"})
        if title is not None:
            return title.text.strip()
        else:
            return "Tag not found"

    def product_price(self):
        price = self.soup.find("span", {"class": "a-offscreen"})
        if price is not None:
            return price.text
        else:
            return "Tag not found"
#device = PriceTracer(url="https://www.amazon.in/gp/aw/d/B0CX59SD6C/?_encoding=UTF8&pd_rd_plhdr=t&aaxitk=a4a937daddc4ca2c679f89d81fa64012&hsa_cr_id=0&qid=1744985795&sr=1-1-fd947bf3-57d2-4cc9-939d-2805f92cef28&ref_=sbx_be_s_sparkle_lsi4d_asin_0_img&pd_rd_w=ciMal&content-id=amzn1.sym.845f57b6-55e4-4cbd-87c4-a6995e751b3a%3Aamzn1.sym.845f57b6-55e4-4cbd-87c4-a6995e751b3a&pf_rd_p=845f57b6-55e4-4cbd-87c4-a6995e751b3a&pf_rd_r=CDH5K4F7F3SV3XGPSJDE&pd_rd_wg=2iFey&pd_rd_r=2fd392e3-1add-4029-90c9-d90b5aa3ac21&th=1")
device = PriceTracer(
    url="https://www.amazon.in/gp/aw/d/B0CX59SD6C"
)
print("Product Title:", device.product_title())
print("Product Price:", device.product_price())